--create projects--
INSERT INTO project VALUES('School
fees','adam1993@gmail.com',0,1000,'2017-03-10','2017-04-10','2017-10-10','false','Raising
money for my school fees','111-33333-444','http://www.mis.ac.th/fees.jpg');
INSERT INTO project VALUES('Making Potato Salad',
'bruceli@hotmail.com',0,15,'2017-03-10','2017-04-10','2017-04-10','false','Need money for
lunch','012345678','http://food.fnr.sndimg.com/content/dam/images/food/fullset/2006/9/22/0/ig07
07_potato_salad1.jpg.rend.hgtvcom.616.462.suffix/1428086524917.jpeg');
INSERT INTO project VALUES('Food for the needy',
'edgydude1888@gmail,com',0,215,'2017-07-10','2017-08-10','2017-12-27','false','Money raised
will go into food supplies for the
needy','123459784','http://challengeforsustainability.org/wp-content/uploads/2014/07/food-donati
on.jpg');
INSERT INTO project VALUES('Retirement fund',
'oldguy88@gmail.com',0,500,'2017-03-11','2017-04-11','2018-12-22','false','CPF not
enough.','5559999955','http://www.retirementplanningconnecticut.com/wp-content/uploads/2016/
12/Retirement.jpg');
INSERT INTO project VALUES('Charity Performance',
'rencicharityfund@gmail.com',0,10000,'2017-03-12','2017-04-12','2017-10-10','false','We are a
charity organisation looking for sponsors for our annual
performance','987654321','http://www.tunbridgewellskidsonthego.co.uk/wp-content/uploads/2014
/07/Flyer-for-Charity-Concert-2014-e1405025428575.jpg');
INSERT INTO project VALUES('Funds for hospital fees',
'nicktan111@hotmail.com',0,2030,'2017-07-11','2017-08-11','2017-12-20','false','Father in hospital,
no money for
fees','123789456','https://www.ucsf.edu/sites/default/files/styles/300w/public/fields/field_insert_file/
news/calculator-stethescope-hospital-bill-costs_0.jpg');
INSERT INTO project VALUES('New web series',
'susantan99@hotmail.com',0,2050,'2017-06-11','2017-06-11','2018-01-31','false','Starting a new
web series. Need funds.',
'885296374','http://www.indiantelevision.com/sites/drupal7.indiantelevision.co.in/files/images/intern
et-images/2016/04/25/Web-Series-Scripted.png');
INSERT INTO project VALUES('Trip to Europe',
'wewlad@gmail.com',0,1500,'2017-11-15','2018-11-20','2019-11-25','false','Looking to fund my
trip to
Europe.','963852741','https://shatorch.com/wp-content/uploads/2016/05/eurpoa-travel.jpg');
INSERT INTO project VALUES('BBQ party',
'heyimsam@gmail.com',0,199,'2017-10-25','2018-04-11','2018-11-11','false','Hosting a party, all
funders
welcomed!','963741852','https://shatorch.com/wp-content/uploads/2016/05/eurpoa-travel.jpg');